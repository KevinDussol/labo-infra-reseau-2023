kubeadm join 10.0.0.10:6443 --token jqll8r.jlmvimcx57cvdfxc --discovery-token-ca-cert-hash sha256:60c54333e82a2b44eedf60ac83a924322e8f48428770c3be6e876160f0378bd2 
